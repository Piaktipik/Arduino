The diff between the FreeRTOS distribution and mods to package FreeRTOS
as Arduino libraries.